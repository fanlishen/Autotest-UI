<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_subjectInterestitem (1)</name>
   <tag></tag>
   <elementGuidId>e7f72833-5ea7-4ef0-9704-323956292598</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>panel-index-content am-g am-g-collapse</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-reactid</name>
      <type>Main</type>
      <value>.0.0.0.0.1.0.1.$1.0</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>学科兴趣兴趣是最好的老师。对学科的兴趣是影响我选考科目的重要因素。</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;leftamination&quot;)/div[@class=&quot;am-u-sm-12&quot;]/div[@class=&quot;panel-index&quot;]/div[@class=&quot;panel-index-content am-g am-g-collapse&quot;]</value>
   </webElementProperties>
</WebElementEntity>
