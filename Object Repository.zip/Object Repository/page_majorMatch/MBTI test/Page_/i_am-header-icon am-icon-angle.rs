<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>i_am-header-icon am-icon-angle</name>
   <tag></tag>
   <elementGuidId>00c07399-b9ae-41e2-b11d-7fd5b526a989</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>i</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>am-header-icon am-icon-angle-left</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-reactid</name>
      <type>Main</type>
      <value>.0.0.0.0.0.0.0.0.0</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;app&quot;)/div[1]/div[1]/div[1]/div[1]/div[1]/header[@class=&quot;am-header am-header-default&quot;]/div[@class=&quot;am-header-left am-header-nav&quot;]/a[1]/i[@class=&quot;am-header-icon am-icon-angle-left&quot;]</value>
   </webElementProperties>
</WebElementEntity>
