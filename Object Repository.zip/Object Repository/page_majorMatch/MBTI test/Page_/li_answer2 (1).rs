<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_answer2 (1)</name>
   <tag></tag>
   <elementGuidId>1d9d3aa8-d63e-4eb9-a8ec-0cb9973e3ac1</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-reactid</name>
      <type>Main</type>
      <value>.0.0.0.0.0.1.0.0.0.1.1.$1</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>表达方式直接明确</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;app&quot;)/div[1]/div[1]/div[1]/div[1]/div[1]/div[@class=&quot;swiper-wrap-root&quot;]/div[@class=&quot;easy-swiper-wrapper clearfix&quot;]/div[@class=&quot;swiper-wrap&quot;]/div[@id=&quot;single-card&quot;]/div[@class=&quot;content&quot;]/ul[1]/li[2]</value>
   </webElementProperties>
</WebElementEntity>
